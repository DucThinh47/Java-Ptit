/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package XepHangHocSinh;

/**
 *
 * @author Duc Thinh
 */
import java.util.*;
public class HocSinh implements Comparable<HocSinh>{
    private String ma, ten;
    private double diem_tb;
    private int hang;
    private String loai;
    public static int cnt = 0;
    
    
    public HocSinh(String ten, double diem_tb){
        this.ma = String.format("HS%02d", ++cnt);
        this.ten = ten;
        this.diem_tb = diem_tb;
        if(diem_tb < 5){
            this.loai = "Yeu";
        }else if(diem_tb < 7){
            this.loai = "Trung binh";
        }else if(diem_tb < 9){
            this.loai = "Kha";
        }else{
            this.loai = "Gioi";
        }
    }
    
    public void setHang(int hang){
        this.hang = hang;
    }
    
    public int getHang(){
        return this.hang;
    }
    
    public double getDiemTb(){
        return this.diem_tb;
    }
    
    @Override
    public int compareTo(HocSinh o){
        if(this.diem_tb < o.diem_tb)
            return 1;
        return -1;
    }
    
    @Override
    public String toString(){
        return String.format("%s %s %.1f %s %d", this.ma, this.ten, this.diem_tb, this.loai, this.hang);
    }
}
