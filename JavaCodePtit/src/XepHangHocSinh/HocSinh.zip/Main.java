/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package XepHangHocSinh;

/**
 *
 * @author Duc Thinh
 */
import java.util.*;
public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        int res = t;
        sc.nextLine();
        ArrayList<HocSinh> al = new ArrayList<>();
        while(t-->0){
            al.add(new HocSinh(sc.nextLine(), Double.parseDouble(sc.nextLine())));
        }
        ArrayList<HocSinh> tmp = (ArrayList<HocSinh>)al.clone();
//        Collections.sort(tmp,new Comparator<HocSinh>(){
//            @Override
//            public int compare(HocSinh o1, HocSinh o2){
//                if(o1.getDiemTb() - o2.getDiemTb() < 0)
//                    return 1;
//                return -1;
//            }
//        });
//        for(HocSinh x : tmp){
//            System.out.println(x);
//        }
        Collections.sort(tmp);
        tmp.get(0).setHang(1);
        for(int i=1; i<res; i++){
            if(tmp.get(i).getDiemTb() == tmp.get(i-1).getDiemTb()){
                tmp.get(i).setHang(tmp.get(i-1).getHang());
            }else{
                tmp.get(i).setHang(i+1);
            }
        }
//        for(HocSinh x : tmp){
//            System.out.println(x);
//        }
//        System.out.println();
        for(HocSinh x : al){
            System.out.println(x);
        }
    }
}
//3
//Tran Minh Hieu
//5.9
//Nguyen Bao Trung
//8.6
//Le Hong Ha
//9.2
