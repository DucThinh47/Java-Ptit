/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai3GK;

/**
 *
 * @author Duc Thinh
 */
public class Mon {
    public String ma_mon, ten_mon;
    public int so_tin;
    
    public Mon(String ma_mon, String ten_mon, int so_tin){
        this.ma_mon = ma_mon;
        this.ten_mon = ten_mon;
        this.so_tin = so_tin;
    }

    public String getMa_mon() {
        return ma_mon;
    }

    public String getTen_mon() {
        return ten_mon;
    }

    public int getSo_tin() {
        return so_tin;
    }
    
    
}
